﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;


namespace DataAccessLayer.Repositories
{
    /// <summary>
    /// IGeneric Data Repository
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IGenericDataRepository<T> where T : class
    {
        /// <summary>
        /// Gets all.
        /// </summary>        
        /// <returns></returns>
        IEnumerable<T> GetAll();   
        /// <summary>
        /// Gets the single.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <param name="navigationProperties">The navigation properties.</param>
        /// <returns></returns>
        T GetSingle(Expression<Func<T, bool>> predicate, params string[] navigationProperties);
        /// <summary>
        /// Adds the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        void Add(params T[] items);
        /// <summary>
        /// Updates the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        void Update(params T[] items);
        /// <summary>
        /// Removes the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        void Delete(params T[] items);
        ///// <summary>
        ///// Saves the specified items.
        ///// </summary>
        //void Save();
        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        T GetById(object id);
        /// <summary>
        /// Generates the identifier.
        /// </summary>
        /// <returns></returns>
        Guid GenerateGId();
    }
}
