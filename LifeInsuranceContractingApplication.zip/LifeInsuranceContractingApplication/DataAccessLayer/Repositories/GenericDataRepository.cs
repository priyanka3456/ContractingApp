﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Entities;
using System.Linq.Expressions;
using System.Configuration;
using System.Data.Entity;

namespace DataAccessLayer.Repositories
{
    /// <summary>
    /// Generic Data Repository
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class GenericDataRepository<T> : IGenericDataRepository<T> where T : class
    {
        string connectionString;
      
        ///// <summary>
        ///// Initializes a new instance of the <see cref="GenericDataRepository{T}"/> class.
        ///// </summary>
        ///// <param name="userModel">The user model.</param>
        public GenericDataRepository()
        {
            connectionString = ConfigurationManager.ConnectionStrings[""].ConnectionString; //Should Add Connection String name from Config file

        }
        /// <summary>
        /// Adds the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        void IGenericDataRepository<T>.Add(params T[] items)
        {            
            using (var context = new DbContext(connectionString))
            {
                foreach (T item in items)
                {
                    context.Entry(item).State = EntityState.Added;
                }
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Gets all.
        /// </summary>       
        /// <returns></returns>
        public virtual IEnumerable<T> GetAll()
        {
            using (var context = new DbContext(connectionString))
            {
                IQueryable<T> query = context.Set<T>();
                return query.ToList();

            }

        }   
        /// <summary>
        /// Gets the single.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <param name="navigationProperties">The navigation properties.</param>
        /// <returns></returns>
        public virtual T GetSingle(Expression<Func<T, bool>> predicate, params string[] navigationProperties)
        {
            T item = null;
            using (DbContext ctx = new DbContext(connectionString))
            {
                var query = ctx.Set<T>().AsQueryable();

                foreach (string navigationProperty in navigationProperties)
                query = query.Include(navigationProperty);

                item = query.Where(predicate).FirstOrDefault<T>();
            }
            return item;
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public virtual T GetById(object id)
        {
            T item = null;
            using (var context = new DbContext(connectionString))
            {
                DbSet<T> DbSet = context.Set<T>();
                item = DbSet.Find(id);
            }
            return item;
        }

        /// <summary>
        /// Removes the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        void IGenericDataRepository<T>.Delete(params T[] items)
        {
            using (var context = new DbContext(connectionString))
            {
                foreach (T item in items)
                {
                    context.Entry(item).State = EntityState.Deleted;
                }
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Updates the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        void IGenericDataRepository<T>.Update(params T[] items)
        {
            using (var context = new DbContext(connectionString))
            {
                foreach (T item in items)
                {
                    context.Entry(item).State = EntityState.Modified;
                }
                context.SaveChanges();
            }

        }
        /// <summary>
        /// Generates the g identifier.
        /// </summary>
        /// <returns></returns>
        public Guid GenerateGId()
        {
            var buffer = Guid.NewGuid().ToByteArray();

            var time = new DateTime(0x76c, 1, 1);
            var now = DateTime.UtcNow;
            var span = new TimeSpan(now.Ticks - time.Ticks);
            var timeOfDay = now.TimeOfDay;

            var bytes = BitConverter.GetBytes(span.Days);
            var array = BitConverter.GetBytes(
                (long)(timeOfDay.TotalMilliseconds / 3.333333));

            Array.Reverse(bytes);
            Array.Reverse(array);
            Array.Copy(bytes, bytes.Length - 2, buffer, buffer.Length - 6, 2);
            Array.Copy(array, array.Length - 4, buffer, buffer.Length - 4, 4);

            return new Guid(buffer);
        }

       
    }
}
