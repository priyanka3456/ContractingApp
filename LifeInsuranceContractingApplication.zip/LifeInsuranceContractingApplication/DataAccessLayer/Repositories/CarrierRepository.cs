﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Entities;

namespace DataAccessLayer.Repositories
{
    /// <summary>
    /// The Carrier Repository
    ///</summary>
    public class CarrierRepository
    {
        /// <summary>
        /// Add or Update Carrier Entity Details
        /// </summary> 
        /// <param name="carrierModel">The Carrier Entity Details</param>
        /// <param name="newCarrierEntity">The New or Existing Entity</param>
        /// <returns></returns>
        public void AddOrUpdateCarrierModelEntity(CarrierEntity carrierEntity, bool newCarrierEntity)
        {
            try
            {
                IGenericDataRepository<CarrierEntity> genericDataRepository = new GenericDataRepository<CarrierEntity>();
                if (newCarrierEntity) //Add a new carrier record in db
                {
                    
                    genericDataRepository.Add(carrierEntity);

                }
                else //update an existing record in db
                {
                    genericDataRepository.Update(carrierEntity);
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
