﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DataAccessLayer.Entities
{

    /// <summary>
    /// Advisor Entity
    /// </summary>
    public class AdvisorEntity
    {
        /// <summary>
        /// Gets or sets the Advisor identifier.
        /// </summary>
        /// <value>
        /// The Advisor identifier.
        /// </value>
        public System.Guid AdvisorId { get; set; }
        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        public string FirstName { get; set; }
        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        public string LastName { get; set; }
        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        public int PhoneNumber { get; set; }

       // private static readonly Random rand = new Random();

        private KnownColor GetRandomColor { get; set; }

    }
    //public enum ColorsList
    //{
    //    Red =30,
    //    Green=70
    //}
}
