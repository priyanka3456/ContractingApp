﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Entities
{
    /// <summary>
    /// MGA Entity
    /// </summary>
    public class MGAEntity
    {
        /// <summary>
        /// Gets or sets the MGA identifier.
        /// </summary>
        /// <value>
        /// The MGA identifier.
        /// </value>
        public System.Guid MGAId { get; set; }
        /// <summary>
        /// Gets or sets the business name.
        /// </summary>
        /// <value>
        /// The business name.
        /// </value>
        public string BusinessName { get; set; }
        /// <summary>
        /// Gets or sets the business Address.
        /// </summary>
        /// <value>
        /// The business address.
        /// </value>
        public string BusinessAddress { get; set; }
        /// <summary>
        /// Gets or sets the business number.
        /// </summary>
        /// <value>
        /// The business number.
        /// </value>
        public int BusinessPhoneNumber { get; set; }
    }
}
