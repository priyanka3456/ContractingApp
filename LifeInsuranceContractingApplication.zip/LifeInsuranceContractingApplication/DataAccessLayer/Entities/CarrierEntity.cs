﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Entities
{
    
    /// <summary>
    /// Carrier Entity
    /// </summary>
    public class CarrierEntity
    {
        /// <summary>
        /// Gets or sets the carrier identifier.
        /// </summary>
        /// <value>
        /// The carrier identifier.
        /// </value>
        public System.Guid CarrierId { get; set; }
        /// <summary>
        /// Gets or sets the business name.
        /// </summary>
        /// <value>
        /// The business name.
        /// </value>
        public string BusinessName { get; set; }
        /// <summary>
        /// Gets or sets the business Address.
        /// </summary>
        /// <value>
        /// The business address.
        /// </value>
        public string BusinessAddress { get; set; }
        /// <summary>
        /// Gets or sets the business number.
        /// </summary>
        /// <value>
        /// The business number.
        /// </value>
        public int BusinessPhoneNumber { get; set; }
      
    }
}
