﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Repositories;
using DataAccessLayer.Entities;


namespace Models.Components
{
    public class CarrierComponent
    {
        /// <summary>
        /// Get Carrier Entity List
        /// </summary>       
        /// <returns></returns>
        public IList<CarrierModel> GetCarriers()
        {
            IList <CarrierModel> carrierModels= new List<CarrierModel>();
            IEnumerable<CarrierEntity> carrierEntities = new List<CarrierEntity>();
            IGenericDataRepository<CarrierEntity> genericDataRepository = new GenericDataRepository<CarrierEntity>();
            try
            {
                carrierEntities = genericDataRepository.GetAll();
                if(carrierEntities != null)
                {
                    foreach(var carrierEntity in carrierEntities)
                    {
                        CarrierModel carrierModel = new CarrierModel()
                        {
                            CarrierId = carrierEntity.CarrierId,
                            BusinessName = carrierEntity.BusinessName,
                            BusinessAddress = carrierEntity.BusinessAddress,
                            BusinessPhoneNumber = carrierEntity.BusinessPhoneNumber 
                        };

                        carrierModels.Add(carrierModel);
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return carrierModels;
        }

        /// <summary>
        /// Get Carrier Entity Details
        /// </summary> 
        /// <param name="Guid">The Global Identifier</param>
        /// <returns></returns>
        public CarrierModel GetCarrierEntityDetails(object Guid)
        {
            CarrierModel carrierModel = null;
            CarrierEntity carrierEntity = new CarrierEntity();
            IGenericDataRepository<CarrierEntity> genericDataRepository = new GenericDataRepository<CarrierEntity>();
            try
            {
                carrierEntity = genericDataRepository.GetById(Guid);
                if (carrierEntity != null)
                {
                    carrierModel = new CarrierModel()
                        
                        {
                            CarrierId = carrierEntity.CarrierId,
                            BusinessName = carrierEntity.BusinessName,
                            BusinessAddress = carrierEntity.BusinessAddress,
                            BusinessPhoneNumber = carrierEntity.BusinessPhoneNumber
                        };

                        
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carrierModel;
        }
        /// <summary>
        /// Get Carrier Entity Details Without using Id
        /// </summary> 
        /// <param name="BusinessName">Any Column value in Carrier entity</param>
        /// <returns></returns>
        public CarrierModel GetCarrierEntityDetailsUsingNonId(string BusinessName)
        {
            CarrierModel carrierModel = null;
            CarrierEntity carrierEntity = new CarrierEntity();
            IGenericDataRepository<CarrierEntity> genericDataRepository = new GenericDataRepository<CarrierEntity>();
            try
            {
                carrierEntity = genericDataRepository.GetSingle(x => x.BusinessName == BusinessName);
                if (carrierEntity != null)
                {
                    carrierModel = new CarrierModel()

                    {
                        CarrierId = carrierEntity.CarrierId,
                        BusinessName = carrierEntity.BusinessName,
                        BusinessAddress = carrierEntity.BusinessAddress,
                        BusinessPhoneNumber = carrierEntity.BusinessPhoneNumber
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carrierModel;
        }
        /// <summary>
        /// Add or Update Carrier Entity Details
        /// </summary> 
        /// <param name="carrierModel">The Carrier Entity Details</param>
        /// <param name="newCarrierEntity">The New or Existing Entity</param>
        /// <returns></returns>
        public void AddOrUpdateCarrierModelEntity(CarrierModel carrierModel,bool newCarrierEntity)
        {
            try
            {
                CarrierRepository carrierRepository = new CarrierRepository();
                if(carrierModel != null)
                {
                    CarrierEntity carrierEntity = new CarrierEntity()
                    {
                        CarrierId = carrierModel.CarrierId,
                        BusinessName = carrierModel.BusinessName,
                        BusinessAddress = carrierModel.BusinessAddress,
                        BusinessPhoneNumber = carrierModel.BusinessPhoneNumber

                    };
                    carrierRepository.AddOrUpdateCarrierModelEntity(carrierEntity, newCarrierEntity);
                }                
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Delete Carrier Entity Details
        /// </summary> 
        /// <param name="Guid">The Global Identifier</param>
        /// <returns></returns>
        public void DeleteCarrierEntity(object Guid)
        {
            CarrierEntity carrierEntity = new CarrierEntity();
            IGenericDataRepository<CarrierEntity> genericDataRepository = new GenericDataRepository<CarrierEntity>();
            try
            {
                carrierEntity = genericDataRepository.GetById(Guid);
                if (carrierEntity != null)
                {
                    genericDataRepository.Delete(carrierEntity);
                    //delete or close all the contracts assosiated with deleted carrier entity
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
