﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Models.Components;
using Models.Models;

namespace WebClient.Controllers
{
    /// <summary>
    /// Carrier Controller
    /// </summary>
    public class CarrierController 
    {
        /// <summary>
        /// Get Carrier Entity List
        /// </summary>       
        /// <returns></returns>
        public IList<CarrierModel> GetAllCarriers()
        {
            IList<CarrierModel> carrierModelList = null;
            CarrierComponent carrierComponent = new CarrierComponent();
            try
            {
                carrierModelList = new List<CarrierModel>();
                carrierModelList = carrierComponent.GetCarriers();
            }

            catch(Exception ex)
            {
                throw ex;
            }
            return carrierModelList;
        }
        /// <summary>
        /// Get Carrier Entity Details using Id
        /// </summary>       
        /// <returns></returns>
        public CarrierModel GetCarrierDetails()
        {
            CarrierModel carrierModel = new CarrierModel();
            var Guid = new System.Guid(); //should use proper id from UI
            try
            {
                CarrierComponent carrierComponent = new CarrierComponent();
                carrierModel = carrierComponent.GetCarrierEntityDetails(Guid);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return carrierModel;
        }

        /// <summary>
        /// Get Carrier Entity Details using other fields
        /// </summary>       
        /// <returns></returns>
        public CarrierModel GetCarrierDetailsUsingNonId()
        {
            CarrierModel carrierModel = new CarrierModel();
            string BusinessName = "ABC"; //need input from UI
            CarrierComponent carrierComponent = new CarrierComponent();
            try
            {
                
                carrierModel = carrierComponent.GetCarrierEntityDetailsUsingNonId(BusinessName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carrierModel;
        }

        /// <summary>
        /// Update Carrier Entity Details 
        /// </summary>       
        /// <returns></returns>
        public void AddOrUpdateCarrierModelEntity() //need model object from UI
        {
            CarrierModel carrierModel = new CarrierModel() //Sample Object
            {
                CarrierId = new Guid(),
                BusinessName = "ABC",
                BusinessAddress = "XYZ",
                BusinessPhoneNumber = 987654332
            };
            bool newCarrierEntity = true; //If set to true, new entity is added, if set to false then existing entity is updated
            CarrierComponent carrierComponent = new CarrierComponent();
            try
            {
                carrierComponent.AddOrUpdateCarrierModelEntity(carrierModel,newCarrierEntity);
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }

        ///<summary>
        /// Delete Carrier Entity Details 
        /// </summary>       
        /// <returns></returns>
        public void DeleteCarrierEntity()
        {
            var Guid = new System.Guid(); //should use proper id from UI

            try
            {
                CarrierComponent carrierComponent = new CarrierComponent();
                carrierComponent.DeleteCarrierEntity(Guid);
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
